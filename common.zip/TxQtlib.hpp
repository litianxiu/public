#pragma once

#include "TxStdlib.hpp"
#include "TxSyslib.hpp"
#include "TxBoostlib.hpp"

#include <functional>
#include <set>
#include <map>
#include <assert.h>

#include <QtCore/QDir>
#include <QtCore/QUuid>
#include <QtCore/QRect>
#include <QtCore/QEvent>
#include <QtCore/QtMath>
#include <QtCore/QMutex>
#include <QtCore/QThread>
#include <QtCore/QObject>
#include <QtCore/QFileInfo>
#include <QtCore/QLibraryInfo>
#include <QtCore/QTranslator>
#include <QtCore/QJsonArray>
#include <QtCore/QJsonObject>
#include <QtCore/QJsonDocument>
#include <QtCore/QJsonParseError>
#include <QtCore/QTimer>
#include <QtCore/QIODevice>
#include <QtCore/QFile>
#include <QtCore/QByteArray>
#include <QtCore/QStandardPaths>
#include <QtGui/QPainter>
#include <QtGui/QPixmap>
#include <QtCore/QBuffer>
#include <QtGui/QImage>
#include <QtGui/QMovie>
#include <QtWidgets/QWidget>
#include <QtWidgets/QDialog>
#include <QtWidgets/QApplication>
#include <QtWidgets/QMainWindow>
#include <QtWidgets/QGridLayout>
#include <QtWidgets/QDesktopWidget>
#include <QtWidgets/QTextEdit>
#include <QtWidgets/QTextBrowser>
#include <QtWidgets/QLabel>
#include <QtWidgets/QPushButton>
#include <QtWidgets/QToolButton>
#include <QtWidgets/QFrame>
#include <QtWidgets/QSlider>
#include <QtWidgets/QMessageBox>
#include <QtWidgets/QScrollBar>
#include <QtWidgets/QListWidget>
#include <QtWidgets/QListWidgetItem>
#include <QtWidgets/QStackedWidget>
#include <QtWidgets/QTabWidget>
#include <QtWidgets/QStatusBar>
#include <QtWidgets/QMenuBar>
#include <QtWidgets/QTableWidget>


namespace _TxPrivateNs_ {
	class CQtlibBase
	{
	public:
		inline static void assertMainThread()
		{
#ifndef NDEBUG
			bool lc_sign = true;
			if (lc_sign && !isMainThread())
			{
				lc_sign = false;
				QMessageBox::critical(NULL, QString::fromStdWString(L"error"),
					QString::fromStdWString(L"TxQtlib::assertMainThread()"), QMessageBox::Ok);
				lc_sign = true;
			}
#endif
		}
		static bool isMainThread()
		{
			struct TTT {
				const Qt::HANDLE dw_main_thread_id;
				TTT() :dw_main_thread_id(QThread::currentThreadId()) { }
			};
			static TTT ttt;
			return ttt.dw_main_thread_id == QThread::currentThreadId();
		}
		static void initEnv()
		{
			isMainThread();
			assertMainThread();
		}
	};

	class _MyQtWindowGlobal
	{
	private:
		long long _tmp1_[1];
		long lMsgBoxRefCount;
		long long _tmp2_[1];
		std::map<TxBlobWString, TxBlobWString> map_wap_file;
		long long _tmp3_[1];
		QMutex mMutex;
	public:
		_MyQtWindowGlobal()
		{
			this->lMsgBoxRefCount = 0;
		}
		~_MyQtWindowGlobal()
		{
			if (this->lMsgBoxRefCount != 0)
			{
				sysLogError("if (this->lMsgBoxRefCount != 0)��������this->iMsgBoxCount=��{0}��").args(this->lMsgBoxRefCount);
			}
		}
		static _MyQtWindowGlobal* getInstance()
		{
			static _MyQtWindowGlobal ret;
			return &ret;
		}
		int messageBoxRefCount(int _refMsgBoxCount)
		{
			this->mMutex.lock();
			this->lMsgBoxRefCount += (long)_refMsgBoxCount;
			int ret = (int)this->lMsgBoxRefCount;
			this->mMutex.unlock();
			return ret;
		}
		void mapWavFile(TxBlobWString *_local_wav_file, const TxBlobWString &_temp_dir_, const TxBlobWString &_wav_qt_res_file)
		{
			this->mMutex.lock();
			auto find_iter = this->map_wap_file.find(_wav_qt_res_file);
			if (find_iter != this->map_wap_file.end())
				*_local_wav_file = find_iter->second;
			if (_local_wav_file->length() <= 0)
			{
				*_local_wav_file = _temp_dir_.trimRight(L"\r\n\t \\") + L"\\"
					+ TxSyslib::generateGuid().utf8Codecvt() + L".wav";
				this->map_wap_file[_wav_qt_res_file] = *_local_wav_file;
			}
			if (!TxBoostlib::isExistFile(*_local_wav_file))
			{
				QFile lcfile(QString::fromWCharArray(_wav_qt_res_file.c_str()));
				if (!lcfile.open(QIODevice::ReadOnly))
				{
					sysLogError("if (!lcfile.open(QIODevice::ReadOnly))���ļ�ʧ�ܡ�_wav_qt_res_file=��{0}��").args(_wav_qt_res_file);
				}
				else
				{
					QByteArray lcFileData = lcfile.readAll();
					lcfile.close();
					TxBoostlib::writeFile(*_local_wav_file, TxBlobString(lcFileData.data(), lcFileData.size()));
				}
			}
			this->mMutex.unlock();
		}
	};

	class CQtlib : public CQtlibBase
	{
	private:
		template<class Wnd>
		static void _start_loop_dlg_(int _msec, int *_loopSign, const std::function<bool(Wnd*)> &_loopFn, const std::weak_ptr<Wnd> &_wnd)
		{
			std::shared_ptr<Wnd> lc_spWnd = _wnd.lock();
			if (lc_spWnd&&_loopFn&&_msec >= 0)
			{
				if ((*_loopSign) == 0 || !_loopFn(lc_spWnd.get()))
				{
					(*_loopSign) = 0;
					lc_spWnd->close();
				}
				QTimer::singleShot(_msec, [_loopFn, _wnd, _msec, _loopSign]() {
					_start_loop_dlg_(_msec, _loopSign, _loopFn, _wnd);
				});
			}
		}
		static QMessageBox::StandardButton _messagebox__(QWidget *_parent,
			const std::function<void(QMessageBox*)> &_initFn, const std::function<bool(QMessageBox*)> &_loopFn)
		{
			_MyQtWindowGlobal::getInstance()->messageBoxRefCount(1);
			std::shared_ptr<QMessageBox> lc_dlg = std::make_shared<QMessageBox>(_parent);
			lc_dlg->setTextFormat(Qt::PlainText);
			if (_initFn)
				_initFn(lc_dlg.get());
			int lc_loopSign = 1;
			_start_loop_dlg_<QMessageBox>(300, &lc_loopSign, _loopFn, lc_dlg);
			QMessageBox::StandardButton ret = (QMessageBox::StandardButton)lc_dlg->exec();
			if (_MyQtWindowGlobal::getInstance()->messageBoxRefCount(-1) < 0)
			{
				sysLogError("�����쳣��_MyQtWindowGlobal::getInstance()->messageBoxRefCount(0)=��{0}��").args(
					_MyQtWindowGlobal::getInstance()->messageBoxRefCount(0));
			}
			return ret;
		}
		template<class WND>
		static void _centerWidget__(WND *_w, double _dScreenSizeRatio, const QSize &_wnd_size, QWidget *_screen_widget)
		{
			QDesktopWidget *lc_desktop = QApplication::desktop();
			QRect lcScreenRect(0, 0, 0, 0);
			lcScreenRect = lc_desktop->availableGeometry(_screen_widget);
			if (lcScreenRect.width() <= 0 || lcScreenRect.height() <= 0)
				lcScreenRect = lc_desktop->availableGeometry();
			if (lcScreenRect.width() <= 0 || lcScreenRect.height() <= 0)
				lcScreenRect = QRect(QPoint(0, 0), _wnd_size);
			if (lcScreenRect.width() <= 0 || lcScreenRect.height() <= 0)
				lcScreenRect = QRect(QPoint(0, 0), QSize(1024, 720));

			QSize lc_wnd_size = _wnd_size;
			if (_dScreenSizeRatio >= 0)
			{
				lc_wnd_size = QSize((int)(lcScreenRect.width()*_dScreenSizeRatio + 0.5f),
					(int)(lcScreenRect.height()*_dScreenSizeRatio + 0.5f));
			}

			QRect lcRealGeom(QPoint(lcScreenRect.left() + (lcScreenRect.width() - lc_wnd_size.width()) / 2,
				lcScreenRect.top() + (lcScreenRect.height() - lc_wnd_size.height()) / 2), lc_wnd_size);
			if (_w->geometry() != lcRealGeom)
				_w->setGeometry(lcRealGeom);
		}
		template<class WND>
		static inline QWidget* _transQWidgetPtr_(WND *_w)
		{
			return _w;
		}
	public:
		static QMessageBox::StandardButton messagebox(QWidget *_parent, const QMessageBox::StandardButtons &_stdBtns,
			const QString &_text, const QString &_title = QString(), QMessageBox::Icon _msg_icon = QMessageBox::Information,
			const QMessageBox::StandardButton &_defaultButton = QMessageBox::NoButton,
			const std::function<bool(QMessageBox*)> &_loopFn = std::function<bool(QMessageBox*)>())
		{
			return _messagebox__(_parent, [_stdBtns, _text, _title, _msg_icon, _defaultButton](QMessageBox *_msgBox) {
				_msgBox->setIcon(_msg_icon);
				_msgBox->setWindowFlags(_msgBox->windowFlags() | Qt::WindowStaysOnTopHint);
				_msgBox->setStandardButtons(_stdBtns);
				_msgBox->setText(_text);
				if (_title.length() > 0)
					_msgBox->setWindowTitle(_title);
				if (_defaultButton != QMessageBox::NoButton)
					_msgBox->setDefaultButton(_defaultButton);
			}, _loopFn);
		}
		static QMessageBox::StandardButton messagebox(QWidget *_parent, const std::function<void(QMessageBox*)> &_initFn,
			const std::function<bool(QMessageBox*)> &_loopFn = std::function<bool(QMessageBox*)>())
		{
			return _messagebox__(_parent, _initFn, _loopFn);
		}
		static int getMessageBoxCount()
		{
			return _MyQtWindowGlobal::getInstance()->messageBoxRefCount(0);
		}
		template<class WND>
		static void centerWidget(WND *_w, const QSize &_wnd_size, QWidget *_screen_widget = NULL)
		{
			TxQtEnvironment::assertMainThread();
			return _centerWidget__(_w, -1.0, _wnd_size, (_screen_widget == NULL ? _transQWidgetPtr_(_w) : _screen_widget));
		}
		template<class WND>
		static void centerWidget(WND *_w, QWidget *_screen_widget = NULL)
		{
			TxQtEnvironment::assertMainThread();
			return _centerWidget__(_w, -1.0, _w->size(), (_screen_widget == NULL ? _transQWidgetPtr_(_w) : _screen_widget));
		}
		template<class WND>
		static void centerWidget(WND *_w, double _dScreenSizeRatio, QWidget *_screen_widget = NULL)
		{
			TxQtEnvironment::assertMainThread();
			return _centerWidget__(_w, _dScreenSizeRatio, _w->size(), (_screen_widget == NULL ? _transQWidgetPtr_(_w) : _screen_widget));
		}

		//ui�������
		template<class WND>
		static void setVisible(WND *_w, bool _visible)
		{
			if (_w->isVisible() != _visible)
				_w->setVisible(_visible);
		}
		static void setEnabled(QWidget *_w, bool _enabled)
		{
			if (_w->isEnabled() != _enabled)
				_w->setEnabled(_enabled);
		}
		template<class WND>
		static void setGeometry(WND *_w, const QRect &_rect)
		{
			if (_w->geometry() != _rect)
				_w->setGeometry(_rect);
		}
		template<class WND>
		static bool setText(WND *_w, const QString &_text)
		{
			if (_w->text().compare(_text) != 0)
			{
				_w->setText(_text);
				return true;
			}
			return false;
		}
		template<class WND>
		static bool setPlainText(WND *_w, const QString &_text)
		{
			if (_w->toPlainText().compare(_text) != 0)
			{
				_w->setPlainText(_text);
				return true;
			}
			return false;
		}
		template<class WND, class VALUE>
		static void setValue(WND *_w, const VALUE &_val)
		{
			if (_w->value() != _val)
				_w->setValue(_val);
		}
		template<class WND>
		static void setCurrentWidget(WND *_w, QWidget *_curWidget)
		{
			if (_w->currentWidget() != _curWidget)
				_w->setCurrentWidget(_curWidget);
		}
		template<class WND>
		static void setChecked(WND *_w, bool _checked)
		{
			if ((!!_w->isChecked()) ^ (!!_checked))
				_w->setChecked(_checked);
		}
		template<class WND>
		static void setFixedSize(WND *_w, const QSize &_size)
		{
			if (_w->minimumSize() != _size || _w->maximumSize() != _size)
				_w->setFixedSize(_size);
		}
		template<class WND>
		static void resize(WND *_w, const QSize &_size)
		{
			if (_w->size() != _size)
				_w->resize(_size);
		}
		template<class WND>
		static void setMinimumSize(WND *_w, const QSize &_size)
		{
			if (_w->minimumSize() != _size)
				_w->setMinimumSize(_size);
		}
		template<class WND>
		static void setMaximumSize(WND *_w, const QSize &_size)
		{
			if (_w->maximumSize() != _size)
				_w->setMaximumSize(_size);
		}
		static void setItemVisible(QListWidgetItem *_w, bool _visible)
		{
			if (_w->isHidden() == _visible)
				_w->setHidden(!_visible);
		}
		template<class WND>
		static bool setElidedText(WND *_w, const QString &_text)
		{
			QMargins lcContentsMargins = _w->contentsMargins();
			QString lcElidedText = _w->fontMetrics().elidedText(_text, Qt::ElideRight,
				_w->width() - lcContentsMargins.left() - lcContentsMargins.right(),
				Qt::TextShowMnemonic | Qt::TextWrapAnywhere);
			if (_w->text().compare(lcElidedText) != 0)
			{
				_w->setText(lcElidedText);
				return true;
			}
			return false;
		}
		template<class WND>
		static void setToolTip(WND *_w, const QString &_toolTip)
		{
			if (_w->toolTip() != _toolTip)
				_w->setToolTip(_toolTip);
		}
		template<class WND>
		static WND* createCenterChildWidget(QWidget *_parent, const QMargins &_margins = QMargins(0, 0, 0, 0))
		{
			QGridLayout *lc_lyt = new QGridLayout(_parent);
			lc_lyt->setContentsMargins(_margins);
			lc_lyt->setSpacing(0);
			WND *ret = new WND(_parent);
			lc_lyt->addWidget(ret);
			return ret;
		}
		static void loadAppStyleSheet(const QString &_filename)
		{
			QFile lc_file(_filename);
			if (lc_file.open(QIODevice::ReadOnly))
			{
				QString lc_qss_data = QString::fromUtf8(lc_file.readAll());
				if (lc_qss_data != qApp->styleSheet())
					qApp->setStyleSheet(lc_qss_data);
			}
			else assert(false);
		}
		static void playSoundFromQtResource(const TxBlobWString &_temp_dir_, const TxBlobWString &_wav_qt_res_file)
		{
			if (_temp_dir_.length() <= 0 || _wav_qt_res_file.length() <= 0)
			{
				sysLogError("if (_temp_dir_.length() <= 0 || _wav_qt_res_file.length() <= 0)��������_temp_dir_=��{0}����_wav_qt_res_file=��{1}��"
				).args(_temp_dir_, _wav_qt_res_file);
			}
			else
			{
				TxBlobWString lc_local_file;
				_MyQtWindowGlobal::getInstance()->mapWavFile(&lc_local_file, _temp_dir_, _wav_qt_res_file);
				if (lc_local_file.length() > 0)
				{
					if (!::PlaySoundW(lc_local_file.c_str(), NULL, SND_NOWAIT))
					{
						sysLogErrorW(L"if (!::PlaySoundW(lc_local_file.c_str(), NULL, SND_NOWAIT))���ش���"
							L"lc_local_file=��{0}��,_wav_qt_res_file=��{1}��,_temp_dir_=��{2}��").args(lc_local_file, _wav_qt_res_file, _temp_dir_);
					}
				}
			}
		}
		static void playLableGif(QWidget *_widget, const QString &_gif_path)
		{
			class MyMovie :public QMovie
			{
			private:
				int iTimerId;
				QLabel *label;
				bool b_play_status;
			public:
				MyMovie(QLabel *_lable) :QMovie(_lable), label(_lable)
				{
					this->b_play_status = false;
					this->iTimerId = __super::startTimer(1000);
				}
				~MyMovie()
				{
					this->killTimer(this->iTimerId);
				}
				void my_start()
				{
					if (this->b_play_status)
						return;
					this->b_play_status = true;
					__super::start();
				}
				void my_stop()
				{
					if (!this->b_play_status)
						return;
					this->b_play_status = false;
					__super::stop();
				}
				virtual void timerEvent(QTimerEvent *_event)
				{
					if (this->iTimerId == _event->timerId())
					{
						if (label->isVisible())
							this->my_start();
						else this->my_stop();
					}
					return __super::timerEvent(_event);
				}
			};
			QLabel *lc_label = dynamic_cast<QLabel*>(_widget);
			if (lc_label == NULL)
			{
				lc_label = new QLabel(_widget);
				QGridLayout *lc_lyt = new QGridLayout(_widget);
				lc_lyt->setMargin(0);
				lc_lyt->addWidget(lc_label);
			}
			if (lc_label->movie() != NULL)
			{
				lc_label->movie()->stop();
				delete lc_label->movie();
			}
			MyMovie *lc_movie = new MyMovie(lc_label);
			lc_label->setMovie(lc_movie);

			lc_movie->my_stop();
			lc_label->setScaledContents(true);
			lc_movie->setFileName(_gif_path);
			lc_movie->my_start();
		}
		static bool generateDesktopShortcut(const QString &_app_path, const QString &_desktop_name)
		{
			bool ret = QFile::link(_app_path,
				QStandardPaths::writableLocation(QStandardPaths::DesktopLocation).append("/").append(
					_desktop_name).append(QString::fromStdWString(L".lnk")));
			assert(ret);
			return ret;
		}
		static void gClearGridLayout(QLayout *_layout)
		{
			if (_layout == NULL)
				return;
			for (int iii = _layout->count(); iii--;)
			{
				QLayoutItem *lc_lyt_item = _layout->itemAt(iii);
				if (lc_lyt_item == NULL)
					assert(false);
				else
				{
					gClearGridLayout(dynamic_cast<QLayout*>(lc_lyt_item));
					QWidget *lc_www = lc_lyt_item->widget();
					if (lc_www != NULL)
					{
						_layout->removeWidget(lc_www);
						delete lc_www;
					}
					_layout->removeItem(lc_lyt_item);
				}
			}
		}
		static void gClearStackedWidget(QStackedWidget *_stackedWidget)
		{
			for (int ii = _stackedWidget->count(); ii--;)
			{
				QWidget *lc_widget_item = _stackedWidget->widget(ii);
				if (lc_widget_item == NULL)
					assert(false);
				else
				{
					_stackedWidget->removeWidget(lc_widget_item);
					delete lc_widget_item;
				}
			}
		}
		static void gClearTabWidget(QTabWidget *_tabWidget)
		{
			for (int ii = _tabWidget->count(); ii--;)
			{
				QWidget *lc_widget = _tabWidget->widget(ii);
				_tabWidget->removeTab(ii);
				if (lc_widget == NULL)assert(false);
				else delete lc_widget;
			}
			assert(_tabWidget->count() == 0);
		}
		static void gClearTableWidget(QTableWidget *_tableWidget)
		{
			for (int yy = (int)_tableWidget->rowCount(); yy--;)
			{
				for (int xx = (int)_tableWidget->colorCount(); xx--;)
				{
					QWidget *lc_widget = _tableWidget->cellWidget(yy, xx);
					if (lc_widget != NULL)
					{
						_tableWidget->removeCellWidget(yy, xx);
						delete lc_widget;
					}
					QTableWidgetItem *lc_item = _tableWidget->item(yy, xx);
					if (lc_item != NULL)
						delete lc_item;
				}
				_tableWidget->removeRow(yy);
			}
		}
		static void gErgodicLayoutInnerWidget(QLayout *_lyt, const std::function<void(QWidget*, int)> &_fnResult)
		{
			for (int ii = 0; ii < _lyt->count(); ++ii)
			{
				QLayoutItem *lc_lyt_item = _lyt->itemAt(ii);
				if (lc_lyt_item == NULL)
					assert(false);
				else
				{
					QWidget *lc_cur_widget = dynamic_cast<QWidget*>(lc_lyt_item->widget());
					if (lc_cur_widget == NULL)
						sysLogError("dynamic_cast<QWidget*>(lc_lyt_item->widget()) return null . 12345612312313");
					else _fnResult(lc_cur_widget, ii);
				}
			}
		}
		static void initEnv()
		{
			TxSyslib::initEnv();
			TxBoostlib::initEnv();
			CQtlibBase::initEnv();
			_MyQtWindowGlobal::getInstance();
		}
	};

	class _MyTranslator_ : public QTranslator
	{
	private:
		std::map<TxBlobString, QString> mapLanguageData;
		QString emptyQString;
		TxBlobString ts_language_key;
		std::list<std::shared_ptr<QTranslator>> listSysTranslator;
	protected:
		virtual QString translate(const char *_context, const char *_sourceText, const char *_disambiguation, int _n) const
		{
			//�˴����ж��߳̽���
			QString ret;
			TxBlobString lc_lang_local_key = this->_match_qt_local_lang_(_sourceText);
			if (lc_lang_local_key.length() > 0)
				ret = this->_find_from_language_key_(lc_lang_local_key);
			if (ret.length() <= 0)
			{
				if (_sourceText != NULL && std::strlen(_sourceText) >= 3 && _sourceText[0] == '[')
				{
					const char *lc_sep_ptr_pos = std::strchr(_sourceText, ']');
					if (lc_sep_ptr_pos != NULL)
						ret = this->_find_from_language_key_(TxBlobString(_sourceText + 1, (int)(lc_sep_ptr_pos - (_sourceText + 1))));
				}
			}
			if (ret.length() <= 0)
				ret = __super::translate(_context, _sourceText, _disambiguation, _n);
			return ret;
		}
	private:
		const QString& _find_from_language_key_(const TxBlobString &_key) const
		{
			auto find_iter = this->mapLanguageData.find(_key);
			if (find_iter == this->mapLanguageData.end())
			{
				sysLogError("if (find_iter == this->mapLanguageData.end())�Ҳ�������key��_key=[{0}]").args(_key);
				return this->emptyQString;
			}
			return find_iter->second;
		}
		static TxBlobString _match_qt_local_lang_(const TxBlobString &_sourceText_key)
		{
			struct T_QT_KEY_LAN {
				std::map<TxBlobString, TxBlobString> data;
				T_QT_KEY_LAN() {
					const char* lc_qt_key_lang[][8] = {
						{ "LGG_qt_redo", "redo" },
						{ "LGG_qt_undo", "undo" },
						{ "LGG_qt_cut", "cut", "cu&t" },
						{ "LGG_qt_copy", "copy" },
						{ "LGG_qt_paste", "paste" },
						{ "LGG_qt_delete", "delete" },
						{ "LGG_qt_select_all", "select all" },
						{ "LGG_qt_unselect", "unselect" },
						{ "LGG_qt_stop", "stop" },
						{ "LGG_qt_reload", "reload" },
						{ "LGG_qt_forward", "forward" },
						{ "LGG_qt_back", "back" },
						{ "LGG_qt_save", "save" },
						{ "LGG_qt_yes", "yes" },
						{ "LGG_qt_no", "no" },
						{ "LGG_qt_ok", "ok" },
						{ "LGG_qt_cancel", "cancel" },
					};
					for (int y = 0; y < sizeof(lc_qt_key_lang) / sizeof(lc_qt_key_lang[0]); ++y)
					{
						for (int x = 1; x < sizeof(lc_qt_key_lang[0]) / sizeof(lc_qt_key_lang[0][0]); ++x)
						{
							if (lc_qt_key_lang[y][x] == NULL)
								break;
							this->data[TxBlobString(lc_qt_key_lang[y][x])] = TxBlobString(lc_qt_key_lang[y][0]);
						}
					}
				}
			};
			static T_QT_KEY_LAN lc_mQtKeyLan;
			auto lc_qt_key_lan_find_iter
				= lc_mQtKeyLan.data.find(TxBlobString(_sourceText_key).toLowerCase().trimLR("\r\n\t &"));
			if (lc_qt_key_lan_find_iter != lc_mQtKeyLan.data.end())
				return lc_qt_key_lan_find_iter->second;
			return TxBlobString();
		}
		void _loadJsonToMapData_(const QString &_languageFile)
		{
			_TxPrivateNs_::CQtlib::assertMainThread();
			QFile lc_file(_languageFile);
			if (!lc_file.open(QIODevice::ReadOnly))
			{
				sysLogError("if(!lc_file.open(QIODevice::ReadOnly | QIODevice::Text))�������ļ�ʧ�ܡ�errorString=[{0}], _languageFile=[{1}]").args(
					lc_file.errorString().toStdWString(), _languageFile.toStdWString());
			}
			else
			{
				QJsonParseError lcJsonParseError;
				QByteArray lcJsonBytes = lc_file.readAll();
				lc_file.close();
				QJsonDocument lcJsonDocument = QJsonDocument::fromJson(lcJsonBytes, &lcJsonParseError);
				if (lcJsonParseError.error != QJsonParseError::NoError)
				{
					sysLogError("if (lcJsonParseError.error() != QJsonParseError::NoError)��������json�ļ�ʧ�ܡ�lcJsonParseError=[{0}]��json=��{1}��").args(
						lcJsonParseError.errorString().toStdWString(), lcJsonBytes.toStdString());
				}
				else
				{
					QJsonObject lcRootJsonObject = lcJsonDocument.object();
					QStringList lcListLangKeys = lcRootJsonObject.keys();
					for (auto iter = lcListLangKeys.begin(); iter != lcListLangKeys.end(); ++iter)
					{
						QJsonValue lcLangValue = lcRootJsonObject[*iter];
						if (!lcLangValue.isObject())
							sysLogError("if (!lcLangValue.isObject())��������lcLangValue.type()=[{0}]").args(lcLangValue.type());
						else
						{
							QJsonValue lcLangContent = lcLangValue.toObject()[QString::fromStdWString(this->ts_language_key.utf8Codecvt())];
							if (!lcLangContent.isString())
								sysLogError("if (!lcLangContent.isString())��������lcLangContent.type()=[{0}]").args(lcLangContent.type());
							else
							{
								this->mapLanguageData[TxBlobWString(iter->toStdWString()).utf8Codecvt()]
									= lcLangContent.toString();
							}
						}
					}
				}
			}
		}
		void _loadSysTranslator()
		{
			_TxPrivateNs_::CQtlib::assertMainThread();
			QString lc_file_suffix;
			if (this->ts_language_key.equalNoCase("chinese"))
				lc_file_suffix = QString::fromStdWString(L"_zh_CN.qm");
			else if (this->ts_language_key.equalNoCase("english"))
				lc_file_suffix = QString::fromStdWString(L"_en.qm");
			else
			{
				assert(false);
				lc_file_suffix = QString::fromStdWString(L"_en.qm");
			}

			for each(QFileInfo mfi in QDir(QLibraryInfo::location(QLibraryInfo::TranslationsPath)).entryInfoList())
			{
				QString lc_path = mfi.absoluteFilePath();
				if (mfi.isFile() && lc_path.length() > lc_file_suffix.length()
					&& lc_path.right(lc_file_suffix.length()).toLower() == lc_file_suffix.toLower())
				{
					std::shared_ptr<QTranslator> lc_spTranslator = std::make_shared<QTranslator>();
					if (lc_spTranslator->load(lc_path))
					{
						if (mfi.fileName().toLower() == (QString::fromStdWString(L"qt") + lc_file_suffix).toLower())
							this->listSysTranslator.push_back(lc_spTranslator);
						else
							this->listSysTranslator.push_front(lc_spTranslator);
					}
				}
			}

			qApp->installTranslator(this);
			for (auto iter = this->listSysTranslator.begin(); iter != this->listSysTranslator.end(); ++iter)
				qApp->installTranslator(iter->get());
		}
	private:
		_MyTranslator_(const _MyTranslator_&)
		{
			TxSysDebugObjectMemory::malloc(this);
			sysLogError("_MyTranslator_(const _MyTranslator_&)��Ӧ���д˲���");
		}
	public:
		_MyTranslator_()
		{
			_TxPrivateNs_::CQtlib::assertMainThread();
			this->_match_qt_local_lang_("");
			TxSysDebugObjectMemory::malloc(this);
		}
		~_MyTranslator_()
		{
			TxSysDebugObjectMemory::free(this);
		}
		void init(const TxBlobString &_languageKey, const QString &_languageFile, bool _bInitQm)
		{
			_TxPrivateNs_::CQtlib::assertMainThread();
			if (this->ts_language_key.length() > 0
				|| _languageKey.length() <= 0
				|| _languageFile.length() <= 0)
			{
				assert(false);
			}
			this->ts_language_key = _languageKey;
			this->_loadJsonToMapData_(_languageFile);
			if (_bInitQm)
				this->_loadSysTranslator();
		}
		const QString& text(const TxBlobString &_key)
		{
			return this->_find_from_language_key_(_key);
		}
		const std::map<TxBlobString, QString>& getLanguageData() const
		{
			return this->mapLanguageData;
		}
	};

	class _MyAutoPrompt_ : public QFrame
	{
	private:
		enum { timer_unit_msec = 80, };
		QTextEdit *pCenterUi;
		int iTimerId;
		int iDisplayTimeMsec;
		QString emptyTitle;
		std::function<void()> fnDestructor;
	private:
		virtual void timerEvent(QTimerEvent *_event)
		{
			if (_event->timerId() == this->iTimerId)
			{
				if (this->iDisplayTimeMsec > 0)
				{
					this->iDisplayTimeMsec -= timer_unit_msec;
				}
				else if (this->isVisible())
				{
					const int lc_delta_height = 2;
					QRect lc_rect = this->geometry();
					this->setGeometry(QRect(lc_rect.topLeft() + QPoint(0, lc_delta_height), lc_rect.size() - QSize(0, lc_delta_height)));
					if (this->geometry().height() == lc_rect.height())
						this->setVisible(false);
				}
			}
			return __super::timerEvent(_event);
		}
		virtual bool event(QEvent *_event)
		{
			switch (_event->type())
			{
			case QEvent::Close:
				this->setVisible(false);
				_event->ignore();
				return true;
				break;
			default:
				break;
			}
			return __super::event(_event);
		}
	private:
		_MyAutoPrompt_(const _MyAutoPrompt_&)
		{
			sysLogError("_MyAutoPrompt_(const _MyAutoPrompt_&)��Ӧ���д˲�����");
			TxSysDebugObjectMemory::malloc(this);
		}
	public:
		_MyAutoPrompt_(QWidget *_parent, const std::function<void()> &_fnDestructor) :QFrame(_parent), fnDestructor(_fnDestructor)
		{
			_TxPrivateNs_::CQtlib::assertMainThread();
			TxSysDebugObjectMemory::malloc(this);
			this->setWindowFlags((this->windowFlags() | Qt::Drawer | Qt::WindowStaysOnTopHint)
				&~(Qt::WindowMinimizeButtonHint | Qt::WindowMaximizeButtonHint | Qt::WindowFullscreenButtonHint));

			this->emptyTitle = QString::fromWCharArray(L"					");
			QVBoxLayout* lc_global_lyt = new QVBoxLayout(this);
			//����ˮƽ������
			lc_global_lyt->addItem(new QSpacerItem(40, 8, QSizePolicy::Expanding, QSizePolicy::Minimum));
			//�����ı���ť
			this->pCenterUi = new QTextEdit(this);
			lc_global_lyt->addWidget(this->pCenterUi);
			//����ˮƽ������
			lc_global_lyt->addItem(new QSpacerItem(40, 8, QSizePolicy::Expanding, QSizePolicy::Minimum));
			this->setStyleSheet(QString::fromWCharArray(L""
				L"*{border:none; background-color: white; color:black; font: bold 11pt \"Arial\";}"));
			this->pCenterUi->setReadOnly(true);
			this->pCenterUi->setAlignment(Qt::AlignCenter);
			this->pCenterUi->verticalScrollBar()->setVisible(false);
			this->pCenterUi->horizontalScrollBar()->setVisible(false);
			this->iTimerId = this->startTimer(timer_unit_msec);
			this->setMinimumHeight(2);
			this->iDisplayTimeMsec = 0;
			this->setVisible(false);
			this->setContextMenuPolicy(Qt::NoContextMenu);
			this->pCenterUi->setContextMenuPolicy(Qt::NoContextMenu);
		}
		~_MyAutoPrompt_()
		{
			TxSysDebugObjectMemory::free(this);
			_TxPrivateNs_::CQtlib::assertMainThread();
			this->killTimer(this->iTimerId);
			if (this->fnDestructor)
				this->fnDestructor();
		}
		void setPromptInformation(int _iDisplayTimeMsec, const QString &_text, const QString &_title)
		{
			_TxPrivateNs_::CQtlib::assertMainThread();
			QString lc_title = _title;
			if (lc_title.length() <= 0)
				lc_title = this->emptyTitle;
			if (lc_title != this->windowTitle())
				this->setWindowTitle(lc_title);
			if (this->pCenterUi->toPlainText() != _text)
				this->pCenterUi->setPlainText(_text);
			this->iDisplayTimeMsec = _iDisplayTimeMsec;
			assert(_iDisplayTimeMsec > 0);
		}
		void showPrompt(bool _bfull)
		{
			_TxPrivateNs_::CQtlib::assertMainThread();
			QSize lc_size;
			if (_bfull) lc_size = QApplication::desktop()->geometry().size();
			else lc_size = QApplication::desktop()->availableGeometry().size();
			this->setGeometry(QRect(QPoint(lc_size.width() - 300, lc_size.height() - 200), QPoint(lc_size.width(), lc_size.height())));
			this->setVisible(true);
		}
		void showPrompt(const QRect &_rect)
		{
			_TxPrivateNs_::CQtlib::assertMainThread();
			this->setGeometry(_rect);
			this->setVisible(true);
		}
	};
}

//--------------------------------------TxQtEnvironment--------------------------------------//
class TxQtEnvironment : public QObject, public TxSingletonTmpl<TxQtEnvironment>
{
private:
	const QEvent::Type iEventPostTaskId;
	std::list<std::shared_ptr<std::function<void(void)>>> mListTask;
	std::shared_ptr<_TxPrivateNs_::_MyTranslator_> spTranslator;
	struct {
		std::map<TxBlobString, QString> emptyMapKeyLang;
		QString emptyQString;
	} emptyObject;
	_TxPrivateNs_::_MyAutoPrompt_ *ptrAutoPrompt;
	QMutex mMutex;
private:
	virtual bool event(QEvent *_event)
	{
		if (_event->type() == this->iEventPostTaskId)
			this->_safe_dealTask();
		return __super::event(_event);
	}
	void _safe_dealTask()
	{
		std::list<std::shared_ptr<std::function<void(void)>>> lc_ListTask;
		this->mMutex.lock();
		lc_ListTask.swap(this->mListTask);
		this->mListTask.clear();
		this->mMutex.unlock();
		for (auto iter = lc_ListTask.begin(), iter_end = lc_ListTask.end(); iter != iter_end; ++iter)
			(**iter)();
	}
	template<class TFUNC>
	void _safe_postTask(const TFUNC &_mfunc)
	{
		auto lc_fn = std::make_shared<std::function<void(void)>>();
		*lc_fn = _mfunc;
		this->mMutex.lock();
		this->mListTask.push_back(lc_fn);
		this->mMutex.unlock();
		QApplication::postEvent(this, new QEvent(this->iEventPostTaskId));
	}
	void _installTranslator_(const TxBlobString &_languageKey, const QString &_languageFile, bool _bInitQm)
	{
		this->mMutex.lock();
		if (this->spTranslator)
			assert(false);
		else
		{
			this->spTranslator = std::make_shared<_TxPrivateNs_::_MyTranslator_>();
			this->spTranslator->init(_languageKey, _languageFile, _bInitQm);
		}
		this->mMutex.unlock();
	}
	const std::map<TxBlobString, QString>& _getLanguageData_() const
	{
		if (!this->spTranslator)
		{
			sysLogError("if (!this->spTranslator)��������");
			return emptyObject.emptyMapKeyLang;
		}
		return this->spTranslator->getLanguageData();
	}
	const QString& _translate_(const TxBlobString &_key)
	{
		if (!this->spTranslator)
		{
			sysLogError("if (!this->spTranslator)��������_key=��{0}��").args(_key);
			return emptyObject.emptyQString;
		}
		return this->spTranslator->text(_key);
	}
	void _showPrompt_(QWidget *_parent, int _iDisplayTimeMsec, const QString &_title, const QString &_text, bool _showFull)
	{
		assertMainThread();
		if (this->ptrAutoPrompt == NULL)
		{
			this->ptrAutoPrompt = new _TxPrivateNs_::_MyAutoPrompt_(_parent, []() {
				assertMainThread();
				TxQtEnvironment *pThis = object();
				if (pThis != NULL)
					pThis->ptrAutoPrompt = NULL;
			});
		}
		if (this->ptrAutoPrompt->parent() != _parent)
			this->ptrAutoPrompt->setParent(_parent);
		this->ptrAutoPrompt->setPromptInformation(_iDisplayTimeMsec, _text, _title);
		this->ptrAutoPrompt->showPrompt(_showFull);
	}
protected:
	TxQtEnvironment() :iEventPostTaskId((QEvent::Type)(QEvent::User + 168))
	{
		_TxPrivateNs_::CQtlib::initEnv();
		_TxPrivateNs_::_MyQtWindowGlobal::getInstance();
		assertMainThread();
		(QEvent::Type)QEvent::registerEventType(this->iEventPostTaskId);
	}
	~TxQtEnvironment()
	{
		assertMainThread();
		this->_safe_dealTask();
		if (this->ptrAutoPrompt != NULL)
		{
			delete this->ptrAutoPrompt;
			this->ptrAutoPrompt = NULL;
		}
	}
public:
	inline static void assertMainThread()
	{
		_TxPrivateNs_::CQtlib::assertMainThread();
	}

	static void installTranslator(const TxBlobString &_languageKey, const QString &_languageFile, bool _bInitQm)
	{
		assertMainThread();
		return object()->_installTranslator_(_languageKey, _languageFile, _bInitQm);
	}
	static const std::map<TxBlobString, QString>& getLanguageData()
	{
		return object()->_getLanguageData_();
	}
	static const QString& translate(const TxBlobString &_key)
	{
		return object()->_translate_(_key);
	}
	template<class TFUNC>
	static void postTask(const TFUNC &_mfunc)
	{
		return object()->_safe_postTask(_mfunc);
	}
	static void showPrompt(bool _showFull, int _iDisplayTimeMsec, const QString &_title, const QString &_text, QWidget *_parent = NULL)
	{
		assertMainThread();
		object()->_showPrompt_(_parent, _iDisplayTimeMsec, _title, _text, _showFull);
	}
};


//--------------------------------------TxQtWindow--------------------------------------//
template<class WND>
class TxQtWindow : public WND
{
private:
	enum {
		E_WM_NCHITTEST = 0x0084,
		E_WM_NCMOUSEMOVE = 0x00A0,
		E_WM_NCLBUTTONDOWN = 0x00A1,
		E_WM_NCLBUTTONUP = 0x00A2,
		E_HTCLIENT = 1,
		E_HTCAPTION = 2,
		E_HTLEFT = 10,
		E_HTRIGHT = 11,
		E_HTTOP = 12,
		E_HTTOPLEFT = 13,
		E_HTTOPRIGHT = 14,
		E_HTBOTTOM = 15,
		E_HTBOTTOMLEFT = 16,
		E_HTBOTTOMRIGHT = 17,
		E_HTBORDER = 18,
	};
private:
	TxObjectLifePeriod::TxObjectEntity mLifeEntity;
	QWidget *uiContainerWidget;
	QGridLayout *uiContainerLayout;
	QPoint m_DragTitleBarPoint;
	QPoint ptTouchCaptionMousePos;//��괥��ʱ����λ��
	QPoint m_invalidPoint;//�����õĵ�ֵ
private:
	bool is_fixed_window_() const
	{
		return this->windowState()&(Qt::WindowMaximized | Qt::WindowFullScreen);
	}
	int get_window_border_L_() const
	{
		return this->is_fixed_window_() ? 0 : 8;
	}
protected:
	virtual int vfGetCaptionHeight() { return 0; }
	virtual bool vfIsWindowCaption(const QPoint &_pt) { (void)&_pt; return false; }
	virtual void vfTouchCaptionEvent() {}//��������������
protected:
	virtual void mousePressEvent(QMouseEvent *_mouseEvent)
	{
		QRect lc_center_w_rect = this->uiContainerWidget->geometry();
		if (lc_center_w_rect.contains(_mouseEvent->pos()) && !this->is_fixed_window_())
		{
			this->ptTouchCaptionMousePos = _mouseEvent->globalPos();
			int lcCaptionHeight = this->vfGetCaptionHeight();
			if (0 < lcCaptionHeight&&_mouseEvent->pos().y() <= lcCaptionHeight + lc_center_w_rect.top())
				this->m_DragTitleBarPoint = _mouseEvent->pos();
		}
		return __super::mousePressEvent(_mouseEvent);
	}
	virtual void mouseReleaseEvent(QMouseEvent *_mouseEvent)
	{
		QPoint lc_deltaTouchXY = this->ptTouchCaptionMousePos - _mouseEvent->globalPos();
		if (TxStdlib::absolute(lc_deltaTouchXY.x()) <= 1 && TxStdlib::absolute(lc_deltaTouchXY.y()) <= 1)
		{
			this->ptTouchCaptionMousePos = this->m_invalidPoint;
			this->vfTouchCaptionEvent();
		}
		else this->ptTouchCaptionMousePos = this->m_invalidPoint;
		this->m_DragTitleBarPoint = this->m_invalidPoint;
		return __super::mouseReleaseEvent(_mouseEvent);
	}
	virtual void mouseMoveEvent(QMouseEvent *_mouseEvent)
	{
		if (this->ptTouchCaptionMousePos != this->m_invalidPoint)
		{
			QPoint lc_deltaTouchXY = this->ptTouchCaptionMousePos - QCursor::pos();
			if (TxStdlib::absolute(lc_deltaTouchXY.x()) > 2 || TxStdlib::absolute(lc_deltaTouchXY.y()) > 2)
				this->ptTouchCaptionMousePos = this->m_invalidPoint;
		}
		if (this->m_DragTitleBarPoint != this->m_invalidPoint)
			this->setGeometry(QRect(_mouseEvent->globalPos() - this->m_DragTitleBarPoint, this->geometry().size()));
		return __super::mouseMoveEvent(_mouseEvent);
	}
	virtual void paintEvent(QPaintEvent *_paintEvent)
	{
		QPainter lc_painter(this);
		lc_painter.setRenderHint(QPainter::Antialiasing, true);

		const int lc_border = this->uiContainerLayout->margin();

		for (int i = 0; i <= lc_border; i++)
		{
			QPainterPath lc_pen_path;
			lc_pen_path.setFillRule(Qt::WindingFill);
			lc_pen_path.addRect(i, i, this->width() - i * 2, this->height() - i * 2);
			lc_painter.setPen(QColor(0, 0, 0, (int)(qPow(i* 16.5f / (float)lc_border, 1.4f)) + 0.5f));
			lc_painter.drawPath(lc_pen_path);
		}

		QPainterPath lc_fill_path;
		lc_fill_path.setFillRule(Qt::WindingFill);
		lc_fill_path.addRect(lc_border, lc_border, this->width() - lc_border * 2, this->height() - lc_border * 2);
		lc_painter.fillPath(lc_fill_path, QBrush(Qt::white));

		lc_painter.end();
	}
	virtual bool event(QEvent *_event)
	{
		if (_event->type() == QEvent::WindowStateChange)
		{
			int lc_border = this->get_window_border_L_();
			if (this->uiContainerLayout->margin() != lc_border)
				this->uiContainerLayout->setMargin(lc_border);
		}
		return __super::event(_event);
	}
	virtual bool nativeEvent(const QByteArray &_eventType, void *_message, long *_result)
	{
#pragma pack(push)
#pragma pack(1)
		typedef struct {
			void* hwnd;				//HWND   hwnd;
			unsigned int message;	//UINT   message;
									//WPARAM wParam;
									//LPARAM lParam;
									//DWORD  time;
									//POINT  pt;
		} T_MY_MSG;
#pragma pack(pop)
		TxQtEnvironment::assertMainThread();
		auto lc_fnIsWindowCaption = [this](const QPoint &_mouseGlbPos)->bool {
			QSize lc_center_w_size = this->uiContainerWidget->size();
			QPoint lc_center_w_pt = this->uiContainerWidget->mapFromGlobal(_mouseGlbPos);
			return 0 <= lc_center_w_pt.x() && lc_center_w_pt.x() < lc_center_w_size.width()
				&& 0 <= lc_center_w_pt.y() && lc_center_w_pt.y() < lc_center_w_size.height()
				&& this->vfIsWindowCaption(lc_center_w_pt);
		};
		if ((unsigned int)((T_MY_MSG*)_message)->message == (unsigned int)E_WM_NCLBUTTONDOWN)
		{
			QPoint lcCursorPoint = QCursor::pos();
			if (lc_fnIsWindowCaption(lcCursorPoint))
				this->ptTouchCaptionMousePos = lcCursorPoint;
		}
		else if ((unsigned int)((T_MY_MSG*)_message)->message == (unsigned int)E_WM_NCLBUTTONUP)
		{
			if (this->ptTouchCaptionMousePos != this->m_invalidPoint)
			{
				QPoint lc_deltaTouchXY = this->ptTouchCaptionMousePos - QCursor::pos();
				if (TxStdlib::absolute(lc_deltaTouchXY.x()) <= 1 && TxStdlib::absolute(lc_deltaTouchXY.y()) <= 1)
				{
					this->ptTouchCaptionMousePos = this->m_invalidPoint;
					this->vfTouchCaptionEvent();
				}
				else this->ptTouchCaptionMousePos = this->m_invalidPoint;
			}
		}
		else if ((unsigned int)((T_MY_MSG*)_message)->message == (unsigned int)E_WM_NCMOUSEMOVE)
		{
			if (this->ptTouchCaptionMousePos != this->m_invalidPoint)
			{
				QPoint lc_deltaTouchXY = this->ptTouchCaptionMousePos - QCursor::pos();
				if (TxStdlib::absolute(lc_deltaTouchXY.x()) > 2 || TxStdlib::absolute(lc_deltaTouchXY.y()) > 2)
					this->ptTouchCaptionMousePos = this->m_invalidPoint;
			}
		}
		else if ((unsigned int)((T_MY_MSG*)_message)->message == (unsigned int)E_WM_NCHITTEST && !this->is_fixed_window_())
		{
			long lc_result = E_HTCLIENT;
			QPoint lcCursorPoint = QCursor::pos();
			if (lc_fnIsWindowCaption(lcCursorPoint))
			{
				lc_result = E_HTCAPTION;
				QPoint lc_deltaTouchXY = this->ptTouchCaptionMousePos - QCursor::pos();
				if (TxStdlib::absolute(lc_deltaTouchXY.x()) <= 1 && TxStdlib::absolute(lc_deltaTouchXY.y()) <= 1)
				{
					if (!(qApp->mouseButtons()&(Qt::LeftButton | Qt::RightButton | Qt::MidButton)))
					{
						this->ptTouchCaptionMousePos = this->m_invalidPoint;
						this->vfTouchCaptionEvent();
					}
				}
				else this->ptTouchCaptionMousePos = this->m_invalidPoint;
			}
			else if (this->uiContainerLayout->margin() > 0)
			{
				QPoint lc_wnd_pt = this->mapFromGlobal(lcCursorPoint);
				QRect lc_inner_rect = this->uiContainerWidget->geometry();
				if (lc_wnd_pt.x() <= lc_inner_rect.left())
				{
					if (lc_wnd_pt.y() <= lc_inner_rect.top())
					{
						if (this->minimumSize() != this->maximumSize())
							lc_result = E_HTTOPLEFT;
						else lc_result = E_HTBORDER;
					}
					else if (lc_wnd_pt.y() >= lc_inner_rect.bottom())
					{
						if (this->minimumSize() != this->maximumSize())
							lc_result = E_HTBOTTOMLEFT;
						else lc_result = E_HTBORDER;
					}
					else
					{
						if (this->minimumWidth() != this->maximumWidth())
							lc_result = E_HTLEFT;
						else lc_result = E_HTBORDER;
					}
				}
				else if (lc_wnd_pt.x() >= lc_inner_rect.right())
				{
					if (lc_wnd_pt.y() <= lc_inner_rect.top())
					{
						if (this->minimumSize() != this->maximumSize())
							lc_result = E_HTTOPRIGHT;
						else lc_result = E_HTBORDER;
					}
					else if (lc_wnd_pt.y() >= lc_inner_rect.bottom())
					{
						if (this->minimumSize() != this->maximumSize())
							lc_result = E_HTBOTTOMRIGHT;
						else lc_result = E_HTBORDER;
					}
					else
					{
						if (this->minimumWidth() != this->maximumWidth())
							lc_result = E_HTRIGHT;
						else lc_result = E_HTBORDER;
					}
				}
				else
				{
					if (lc_wnd_pt.y() <= lc_inner_rect.top())
					{
						if (this->minimumHeight() != this->maximumHeight())
							lc_result = E_HTTOP;
						else lc_result = E_HTBORDER;
					}
					else if (lc_wnd_pt.y() >= lc_inner_rect.bottom())
					{
						if (this->minimumHeight() != this->maximumHeight())
							lc_result = E_HTBOTTOM;
						else lc_result = E_HTBORDER;
					}
				}
			}
			*_result = lc_result;
			return true;
		}
		return __super::nativeEvent(_eventType, _message, _result);
	}
private:
	TxQtWindow(const TxQtWindow&)
	{
		sysLogError("TxQtWindow(const TxQtWindow&)��Ӧ���д˲�����");
		TxSysDebugObjectMemory::malloc(this);
	}
public:
	TxQtWindow(QWidget *_parent, const Qt::WindowFlags &_windowContainFlags = Qt::WindowFlags(),
		const Qt::WindowFlags &_windowEliminateFlags = Qt::WindowFlags()) :WND(_parent)
	{
		TxQtEnvironment::assertMainThread();
		TxSysDebugObjectMemory::malloc(this);
		this->m_DragTitleBarPoint = this->ptTouchCaptionMousePos = this->m_invalidPoint = QPoint(-65535 / 2 + 7, -65535 / 2 + 5);
		this->setWindowFlags((_windowContainFlags | Qt::FramelessWindowHint | Qt::Window)&(~_windowEliminateFlags));

		this->setAttribute(Qt::WA_TranslucentBackground, true);

		QWidget *lc_CentralWidget = this;
		QMainWindow *lc_MainWindow_Temp = dynamic_cast<QMainWindow*>(this);
		if (lc_MainWindow_Temp != NULL)
		{
			lc_CentralWidget = new QWidget(this);
			lc_MainWindow_Temp->setCentralWidget(lc_CentralWidget);
		}
		this->uiContainerLayout = new QGridLayout(lc_CentralWidget);
		this->uiContainerLayout->setSpacing(0);
		this->uiContainerWidget = new QWidget(lc_CentralWidget);
		this->uiContainerLayout->addWidget(this->uiContainerWidget);
		this->uiContainerLayout->setMargin(this->get_window_border_L_());
	}
	virtual ~TxQtWindow()
	{
		TxQtEnvironment::assertMainThread();
		this->getLifePeriod().destroy();
		TxSysDebugObjectMemory::free(this);
	}
	TxObjectLifePeriod getLifePeriod()
	{
		return TxObjectLifePeriod(&this->mLifeEntity);
	}
	QWidget* getContainerWidget()
	{
		TxQtEnvironment::assertMainThread();
		return this->uiContainerWidget;
	}
	void centerWidget(const QSize &_wnd_size, QWidget *_screen_widget = NULL)
	{
		TxQtEnvironment::assertMainThread();
		return _TxPrivateNs_::CQtlib::centerWidget(this, _wnd_size, _screen_widget);
	}
	void centerWidget(QWidget *_screen_widget = NULL)
	{
		TxQtEnvironment::assertMainThread();
		return _TxPrivateNs_::CQtlib::centerWidget(this, _screen_widget);
	}
	void centerWidget(double _dScreenSizeRatio, QWidget *_screen_widget = NULL)
	{
		TxQtEnvironment::assertMainThread();
		return _TxPrivateNs_::CQtlib::centerWidget(this, _dScreenSizeRatio, _screen_widget);
	}
};

//--------------------------------------TxQtPlainWindow--------------------------------------//
template<class WND>
class TxQtPlainWindow : public WND
{
private:
	class UiWidgetWrap : public QWidget
	{
	public:
		std::function<void(const QPoint&)> fnPress;
		std::function<void(const QPoint&)> fnMove;
		TxQtPlainWindow *const uiTopWindow;
	public:
		UiWidgetWrap(QWidget *_parent, TxQtPlainWindow *_uiTopWindow)
			:QWidget(_parent), uiTopWindow(_uiTopWindow)
		{
		}
		virtual bool event(QEvent *_event)
		{
			switch (_event->type())
			{
			case QEvent::MouseButtonPress:
				if (this->fnPress)
					this->fnPress(this->mapToGlobal(dynamic_cast<QMouseEvent*>(_event)->pos()));
				_event->ignore();
				return true;
			case QEvent::MouseMove:
				if (this->fnMove&&this->uiTopWindow->ptRecordPressedPos.x() >= -65536 && this->uiTopWindow->ptRecordPressedPos.y() >= -65536)
					this->fnMove(this->mapToGlobal(dynamic_cast<QMouseEvent*>(_event)->pos()));
				_event->ignore();
				return true;
			case QEvent::MouseButtonRelease:
				this->uiTopWindow->ptRecordPressedPos = QPoint(-99999999, -99999999);
				_event->ignore();
				return true;
			default:
				break;
			}
			return __super::event(_event);
		}
	};
	enum {
		E_WIDGET_BORDER_LEFT = 0,
		E_WIDGET_BORDER_TOP,
		E_WIDGET_BORDER_RIGHT,
		E_WIDGET_BORDER_BOTTOM,
		E_WIDGET_BORDER_TOPLEFT,
		E_WIDGET_BORDER_TOPRIGHT,
		E_WIDGET_BORDER_BOTTOM_LEFT,
		E_WIDGET_BORDER_BOTTOM_RIGHT,
		E_WIDGET_BORDER_END
	};
private:
	TxObjectLifePeriod::TxObjectEntity mLifeEntity;
	QPoint ptRecordPressedPos;
	QWidget *uiOutContainerWidget;
	struct {
		UiWidgetWrap *arBorderWidget[E_WIDGET_BORDER_END];
		QWidget *uiRecordCentralWidget;
		std::list<UiWidgetWrap*> m_listCaptionWidget;//�ɲ�������UI����
		std::list<QRect> m_listOperationRegion;//�ɲ�������
	} mCaptionUi;
private:
	bool is_fixed_window_() const
	{
		return this->windowState()&(Qt::WindowMaximized | Qt::WindowFullScreen);
	}
	void get_window_min_max_size_(QSize *_minSize, QSize *_maxSize)
	{
		*_minSize = this->minimumSize();
		*_maxSize = this->maximumSize();
		_minSize->setWidth(TxStdlib::maximum((int)128, (int)_minSize->width()));
		_minSize->setHeight(TxStdlib::maximum((int)96, (int)_minSize->height()));
		_maxSize->setWidth(TxStdlib::maximum(_maxSize->width(), (int)_minSize->width()));
		_maxSize->setHeight(TxStdlib::maximum(_maxSize->height(), (int)_minSize->height()));
	}
	void _combine_list_titlebar_rect_(std::list<QRect> *_listContainer, std::list<QRect> *_listExclusive)
	{
		if (_listExclusive->size() <= 0)
			return;
		QRect lc_exclusive_rect = _listExclusive->front();
		_listExclusive->pop_front();
		std::list<QRect> lc_new_listContainer;
		for (auto iter = _listContainer->begin(); iter != _listContainer->end(); ++iter)
		{
			if (lc_exclusive_rect.width() > 1 && lc_exclusive_rect.height() > 1
				&& iter->left() < lc_exclusive_rect.right() && lc_exclusive_rect.left() < iter->right()
				&& iter->top() < lc_exclusive_rect.bottom() && lc_exclusive_rect.top() < iter->bottom())
			{
				QRect lc_arry_rect[] = {
					QRect(iter->topLeft(),QPoint(iter->right(),lc_exclusive_rect.top())),
					QRect(iter->topLeft(),QPoint(lc_exclusive_rect.left(),iter->bottom())),
					QRect(QPoint(iter->left(),lc_exclusive_rect.bottom()),iter->bottomRight()),
					QRect(QPoint(lc_exclusive_rect.right(),iter->top()),iter->bottomRight()),
				};
				for (int i = 0; i < TxStdlib::arrayLength(lc_arry_rect); ++i)
				{
					if (lc_arry_rect[i].width() > 1 && lc_arry_rect[i].height() > 1)
						lc_new_listContainer.push_back(lc_arry_rect[i]);
				}
			}
		}
		lc_new_listContainer.sort([](const QRect &_val1, const QRect &_val2)->bool {
			if (_val1.width() < _val2.width())
				return true;
			else if (_val1.width() > _val2.width())
				return false;
			return _val1.height() < _val2.height();
		});
		_listContainer->clear();
		for (auto iter_1 = lc_new_listContainer.rbegin(); iter_1 != lc_new_listContainer.rend(); ++iter_1)
		{
			for (auto iter_2 = _listContainer->begin();; ++iter_2)
			{
				if (iter_2 == _listContainer->end())
				{
					_listContainer->push_back(*iter_1);
					break;
				}
				else if (iter_1->contains(*iter_2, false))
				{
					break;
				}
			}
		}
		_combine_list_titlebar_rect_(_listContainer, _listExclusive);
	}
	void init_ui_()
	{
		this->mCaptionUi.uiRecordCentralWidget = this;
		QMainWindow *lc_MainWindow_Temp = dynamic_cast<QMainWindow*>(this);
		if (lc_MainWindow_Temp != NULL)
		{
			this->mCaptionUi.uiRecordCentralWidget = new QWidget(this);
			lc_MainWindow_Temp->setCentralWidget(this->mCaptionUi.uiRecordCentralWidget);
		}
		this->uiOutContainerWidget = new QWidget(this->mCaptionUi.uiRecordCentralWidget);

		auto lc_fnNewCaptionWidget = [this](Qt::CursorShape _cursorShape,
			const std::function<void(const QPoint&)> &_fnPress,
			const std::function<void(const QPoint&)> &_fnMove)->UiWidgetWrap* {
			UiWidgetWrap *ret = new UiWidgetWrap(this->mCaptionUi.uiRecordCentralWidget, this);
			ret->fnPress = _fnPress;
			ret->fnMove = _fnMove;
			ret->setCursor(_cursorShape);
			//ret->setStyleSheet(QString::fromWCharArray(L"QWidget{background-color: rgb(255, 0, 0);}"));
			return ret;
		};
		this->mCaptionUi.arBorderWidget[E_WIDGET_BORDER_LEFT] = lc_fnNewCaptionWidget(Qt::SizeHorCursor,
			[this](const QPoint &_pt) {
			this->ptRecordPressedPos = this->geometry().topLeft() - _pt;
		}, [this](const QPoint &_pt) {
			QSize lc_minSize, lc_maxSize;
			this->get_window_min_max_size_(&lc_minSize, &lc_maxSize);
			QRect lc_rect = this->geometry();
			lc_rect.setLeft(this->ptRecordPressedPos.x() + _pt.x());
			if (lc_rect.width() < lc_minSize.width())
				lc_rect.setLeft(lc_rect.right() - lc_minSize.width());
			else if (lc_rect.width() > lc_maxSize.width())
				lc_rect.setLeft(lc_rect.right() - lc_maxSize.width() + 1);
			TxQtlib::setGeometry(this, lc_rect);
		});
		this->mCaptionUi.arBorderWidget[E_WIDGET_BORDER_RIGHT] = lc_fnNewCaptionWidget(Qt::SizeHorCursor,
			[this](const QPoint &_pt) {
			this->ptRecordPressedPos = this->geometry().bottomRight() - _pt;
		}, [this](const QPoint &_pt) {
			QSize lc_minSize, lc_maxSize;
			this->get_window_min_max_size_(&lc_minSize, &lc_maxSize);
			QRect lc_rect = this->geometry();
			lc_rect.setRight(this->ptRecordPressedPos.x() + _pt.x());
			if (lc_rect.width() < lc_minSize.width())
				lc_rect.setRight(lc_rect.left() + lc_minSize.width());
			else if (lc_rect.width() > lc_maxSize.width())
				lc_rect.setRight(lc_rect.left() + lc_maxSize.width());
			TxQtlib::setGeometry(this, lc_rect);
		});
		this->mCaptionUi.arBorderWidget[E_WIDGET_BORDER_TOP] = lc_fnNewCaptionWidget(Qt::SizeVerCursor,
			[this](const QPoint &_pt) {
			this->ptRecordPressedPos = this->geometry().topLeft() - _pt;
		}, [this](const QPoint &_pt) {
			QSize lc_minSize, lc_maxSize;
			this->get_window_min_max_size_(&lc_minSize, &lc_maxSize);
			QRect lc_rect = this->geometry();
			lc_rect.setTop(_pt.y() + this->ptRecordPressedPos.y());
			if (lc_rect.height() < lc_minSize.height())
				lc_rect.setTop(lc_rect.bottom() - lc_minSize.height());
			else if (lc_rect.height() > lc_maxSize.height())
				lc_rect.setTop(lc_rect.bottom() - lc_maxSize.height() + 1);
			TxQtlib::setGeometry(this, lc_rect);
		});
		this->mCaptionUi.arBorderWidget[E_WIDGET_BORDER_BOTTOM] = lc_fnNewCaptionWidget(Qt::SizeVerCursor,
			[this](const QPoint &_pt) {
			this->ptRecordPressedPos = this->geometry().bottomRight() - _pt;
		}, [this](const QPoint &_pt) {
			QSize lc_minSize, lc_maxSize;
			this->get_window_min_max_size_(&lc_minSize, &lc_maxSize);
			QRect lc_rect = this->geometry();
			lc_rect.setBottom(this->ptRecordPressedPos.y() + _pt.y());
			if (lc_rect.height() < lc_minSize.height())
				lc_rect.setBottom(lc_rect.top() + lc_minSize.height());
			else if (lc_rect.height() > lc_maxSize.height())
				lc_rect.setBottom(lc_rect.top() + lc_maxSize.height() - 1);
			TxQtlib::setGeometry(this, lc_rect);
		});
		this->mCaptionUi.arBorderWidget[E_WIDGET_BORDER_TOPLEFT] = lc_fnNewCaptionWidget(Qt::SizeFDiagCursor,
			[this](const QPoint &_pt) {
			this->ptRecordPressedPos = this->geometry().topLeft() - _pt;
		}, [this](const QPoint &_pt) {
			QSize lc_minSize, lc_maxSize;
			this->get_window_min_max_size_(&lc_minSize, &lc_maxSize);
			QRect lc_rect = this->geometry();
			lc_rect.setTopLeft(this->ptRecordPressedPos + _pt);
			if (lc_rect.width() < lc_minSize.width())
				lc_rect.setLeft(lc_rect.right() - lc_minSize.width());
			else if (lc_rect.width() > lc_maxSize.width())
				lc_rect.setLeft(lc_rect.right() - lc_maxSize.width() + 1);
			if (lc_rect.height() < lc_minSize.height())
				lc_rect.setTop(lc_rect.bottom() - lc_minSize.height());
			else if (lc_rect.height() > lc_maxSize.height())
				lc_rect.setTop(lc_rect.bottom() - lc_maxSize.height() + 1);
			TxQtlib::setGeometry(this, lc_rect);
		});
		this->mCaptionUi.arBorderWidget[E_WIDGET_BORDER_BOTTOM_RIGHT] = lc_fnNewCaptionWidget(Qt::SizeFDiagCursor,
			[this](const QPoint &_pt) {
			this->ptRecordPressedPos = this->geometry().bottomRight() - _pt;
		}, [this](const QPoint &_pt) {
			QSize lc_minSize, lc_maxSize;
			this->get_window_min_max_size_(&lc_minSize, &lc_maxSize);
			QRect lc_rect = this->geometry();
			lc_rect.setBottomRight(this->ptRecordPressedPos + _pt);
			if (lc_rect.width() < lc_minSize.width())
				lc_rect.setRight(lc_rect.left() + lc_minSize.width());
			else if (lc_rect.width() > lc_maxSize.width())
				lc_rect.setRight(lc_rect.left() + lc_maxSize.width());
			if (lc_rect.height() < lc_minSize.height())
				lc_rect.setBottom(lc_rect.top() + lc_minSize.height());
			else if (lc_rect.height() > lc_maxSize.height())
				lc_rect.setBottom(lc_rect.top() + lc_maxSize.height());
			TxQtlib::setGeometry(this, lc_rect);
		});
		this->mCaptionUi.arBorderWidget[E_WIDGET_BORDER_BOTTOM_LEFT] = lc_fnNewCaptionWidget(Qt::SizeBDiagCursor,
			[this](const QPoint &_pt) {
			this->ptRecordPressedPos = this->geometry().bottomLeft() - _pt;
		}, [this](const QPoint &_pt) {
			QSize lc_minSize, lc_maxSize;
			this->get_window_min_max_size_(&lc_minSize, &lc_maxSize);
			QRect lc_rect = this->geometry();
			lc_rect.setBottomLeft(this->ptRecordPressedPos + _pt);
			if (lc_rect.width() < lc_minSize.width())
				lc_rect.setLeft(lc_rect.right() - lc_minSize.width());
			else if (lc_rect.width() > lc_maxSize.width())
				lc_rect.setLeft(lc_rect.right() - lc_maxSize.width() + 1);
			if (lc_rect.height() < lc_minSize.height())
				lc_rect.setBottom(lc_rect.top() + lc_minSize.height());
			else if (lc_rect.height() > lc_maxSize.height())
				lc_rect.setBottom(lc_rect.top() + lc_maxSize.height());
			TxQtlib::setGeometry(this, lc_rect);
		});
		this->mCaptionUi.arBorderWidget[E_WIDGET_BORDER_TOPRIGHT] = lc_fnNewCaptionWidget(Qt::SizeBDiagCursor,
			[this](const QPoint &_pt) {
			this->ptRecordPressedPos = this->geometry().topRight() - _pt;
		}, [this](const QPoint &_pt) {
			QSize lc_minSize, lc_maxSize;
			this->get_window_min_max_size_(&lc_minSize, &lc_maxSize);
			QRect lc_rect = this->geometry();
			lc_rect.setTopRight(this->ptRecordPressedPos + _pt);
			if (lc_rect.width() < lc_minSize.width())
				lc_rect.setRight(lc_rect.left() + lc_minSize.width());
			else if (lc_rect.width() > lc_maxSize.width())
				lc_rect.setRight(lc_rect.left() + lc_maxSize.width());
			if (lc_rect.height() < lc_minSize.height())
				lc_rect.setTop(lc_rect.bottom() - lc_minSize.height());
			else if (lc_rect.height() > lc_maxSize.height())
				lc_rect.setTop(lc_rect.bottom() - lc_maxSize.height() + 1);
			TxQtlib::setGeometry(this, lc_rect);
		});
	}
private:
	TxQtPlainWindow(const TxQtPlainWindow&)
	{
		sysLogError("TxQtPlainWindow(const TxQtPlainWindow&)��Ӧ���д˲�����");
		TxSysDebugObjectMemory::malloc(this);
		this->ptRecordPressedPos = QPoint(-99999999, -99999999);
	}
public:
	TxQtPlainWindow(QWidget *_parent, const Qt::WindowFlags &_windowContainFlags = Qt::WindowFlags(),
		const Qt::WindowFlags &_windowEliminateFlags = Qt::WindowFlags()) :WND(_parent)
	{
		this->ptRecordPressedPos = QPoint(-99999999, -99999999);
		TxQtEnvironment::assertMainThread();
		TxSysDebugObjectMemory::malloc(this);
		//this->m_DragTitleBarPoint = this->ptTouchCaptionMousePos = this->m_invalidPoint = QPoint(-65535 / 2 + 7, -65535 / 2 + 5);
		this->setWindowFlags((_windowContainFlags | Qt::FramelessWindowHint | Qt::Window)&(~_windowEliminateFlags));
		this->init_ui_();
		this->setOperationRegion(std::list<QRect>());
	}
	virtual ~TxQtPlainWindow()
	{
		TxQtEnvironment::assertMainThread();
		this->getLifePeriod().destroy();
		TxSysDebugObjectMemory::free(this);
	}
	virtual void resizeEvent(QResizeEvent *_resizeEvent)
	{
		QRect lc_wnd_rect = QRect(QPoint(0, 0), _resizeEvent->size());
		if (lc_wnd_rect.width() > 1 && lc_wnd_rect.height() > 1)
		{
			if (this->is_fixed_window_())
			{
				for (int i = 0; i < E_WIDGET_BORDER_END; ++i)
					this->mCaptionUi.arBorderWidget[i]->setVisible(false);
				for (auto iter = this->mCaptionUi.m_listCaptionWidget.begin(); iter != this->mCaptionUi.m_listCaptionWidget.end(); ++iter)
					(*iter)->setVisible(false);
			}
			else
			{
				enum { _E_BORDER_LEN_ = 4, };//�߿��С
				//�߿�
				for (int i = 0; i < E_WIDGET_BORDER_END; ++i)
					this->mCaptionUi.arBorderWidget[i]->setVisible(true);
				if (this->minimumWidth() >= this->maximumWidth())
				{
					this->mCaptionUi.arBorderWidget[E_WIDGET_BORDER_LEFT]->setVisible(false);
					this->mCaptionUi.arBorderWidget[E_WIDGET_BORDER_RIGHT]->setVisible(false);
				}
				if (this->minimumHeight() >= this->maximumHeight())
				{
					this->mCaptionUi.arBorderWidget[E_WIDGET_BORDER_TOP]->setVisible(false);
					this->mCaptionUi.arBorderWidget[E_WIDGET_BORDER_BOTTOM]->setVisible(false);
				}
				this->mCaptionUi.arBorderWidget[E_WIDGET_BORDER_LEFT]->setGeometry(
					QRect(lc_wnd_rect.topLeft(), QPoint(_E_BORDER_LEN_, lc_wnd_rect.bottom())));
				this->mCaptionUi.arBorderWidget[E_WIDGET_BORDER_RIGHT]->setGeometry(QRect(
					QPoint(lc_wnd_rect.right() - _E_BORDER_LEN_, 0), lc_wnd_rect.bottomRight()));
				this->mCaptionUi.arBorderWidget[E_WIDGET_BORDER_TOP]->setGeometry(
					QRect(lc_wnd_rect.topLeft(), QPoint(lc_wnd_rect.right(), _E_BORDER_LEN_)));
				this->mCaptionUi.arBorderWidget[E_WIDGET_BORDER_BOTTOM]->setGeometry(QRect(
					QPoint(lc_wnd_rect.left(), lc_wnd_rect.bottom() - _E_BORDER_LEN_), lc_wnd_rect.bottomRight()));
				//�߽�
				this->mCaptionUi.arBorderWidget[E_WIDGET_BORDER_TOPLEFT]->setGeometry(QRect(
					lc_wnd_rect.topLeft(), 2 * QSize(_E_BORDER_LEN_, _E_BORDER_LEN_)));
				this->mCaptionUi.arBorderWidget[E_WIDGET_BORDER_BOTTOM_RIGHT]->setGeometry(QRect(
					lc_wnd_rect.bottomRight() - 3 * QPoint(_E_BORDER_LEN_, _E_BORDER_LEN_), 3 * QSize(_E_BORDER_LEN_, _E_BORDER_LEN_)));
				this->mCaptionUi.arBorderWidget[E_WIDGET_BORDER_TOPRIGHT]->setGeometry(QRect(
					lc_wnd_rect.topRight() - 2 * QPoint(_E_BORDER_LEN_, 0), 2 * QSize(_E_BORDER_LEN_, _E_BORDER_LEN_)));
				this->mCaptionUi.arBorderWidget[E_WIDGET_BORDER_BOTTOM_LEFT]->setGeometry(QRect(
					lc_wnd_rect.bottomLeft() - 3 * QPoint(0, _E_BORDER_LEN_), 3 * QSize(_E_BORDER_LEN_, _E_BORDER_LEN_)));
			}
			this->uiOutContainerWidget->setGeometry(lc_wnd_rect);
		}
		return __super::resizeEvent(_resizeEvent);
	}
	void setOperationRegion(const std::list<QRect> &_listRegion)
	{
		std::list<QRect> lc_listRegionSort = _listRegion;
		lc_listRegionSort.sort([](const QRect &_a1, const QRect &_a2)->bool {
			return (_a1.width() != _a2.width()) ? (_a1.width() < _a2.width()) : (_a1.height() < _a2.height());
		});
		std::list<QRect> lc_listRegionClean;
		for (auto iter = lc_listRegionSort.rbegin(); iter != lc_listRegionSort.rend(); ++iter)
		{
			if (iter->width() > 1 && iter->height() > 1)
			{
				for (auto iter_2 = lc_listRegionClean.begin();; ++iter_2)
				{
					if (iter_2 == lc_listRegionClean.end())
					{
						lc_listRegionClean.push_back(*iter);
						break;
					}
					else if (iter_2->contains(*iter, false))
					{
						break;
					}
				}
			}
		}
		this->mCaptionUi.m_listOperationRegion = lc_listRegionClean;
		std::list<QRect> lc_listContainer;
		lc_listContainer.push_back(QRect(QPoint(0, 0), this->geometry().size()));
		this->_combine_list_titlebar_rect_(&lc_listContainer, &lc_listRegionClean);
		while (this->mCaptionUi.m_listCaptionWidget.size() < lc_listContainer.size())
		{
			this->mCaptionUi.m_listCaptionWidget.push_back(new UiWidgetWrap(this->mCaptionUi.uiRecordCentralWidget, this));
			//this->mCaptionUi.m_listCaptionWidget.back()->setStyleSheet(QString::fromWCharArray(L"QWidget{background-color: rgb( 0,255, 0);}"));
			this->mCaptionUi.m_listCaptionWidget.back()->fnPress = [this](const QPoint &_pt) {
				this->ptRecordPressedPos = this->geometry().topLeft() - _pt;
			};
			this->mCaptionUi.m_listCaptionWidget.back()->fnMove = [this](const QPoint &_pt) {
				this->move(this->ptRecordPressedPos + _pt);
			};
		}
		while (this->mCaptionUi.m_listCaptionWidget.size() > lc_listContainer.size())
		{
			delete this->mCaptionUi.m_listCaptionWidget.back();
			this->mCaptionUi.m_listCaptionWidget.pop_back();
		}

		auto iter_1 = this->mCaptionUi.m_listCaptionWidget.begin();
		auto iter_2 = lc_listContainer.begin();
		for (; iter_1 != this->mCaptionUi.m_listCaptionWidget.end() && iter_2 != lc_listContainer.end(); ++iter_1, ++iter_2)
		{
			(*iter_1)->raise();
			TxQtlib::setGeometry(*iter_1, *iter_2);
		}
		for (int ii = 0; ii < TxStdlib::arrayLength(this->mCaptionUi.arBorderWidget); ++ii)
			this->mCaptionUi.arBorderWidget[ii]->raise();
	}
	TxObjectLifePeriod getLifePeriod()
	{
		return TxObjectLifePeriod(&this->mLifeEntity);
	}
	QWidget* getContainerWidget()
	{
		TxQtEnvironment::assertMainThread();
		return this->uiOutContainerWidget;
	}
	void centerWidget(const QSize &_wnd_size, QWidget *_screen_widget = NULL)
	{
		TxQtEnvironment::assertMainThread();
		return _TxPrivateNs_::CQtlib::centerWidget(this, _wnd_size, _screen_widget);
	}
	void centerWidget(QWidget *_screen_widget = NULL)
	{
		TxQtEnvironment::assertMainThread();
		return _TxPrivateNs_::CQtlib::centerWidget(this, _screen_widget);
	}
	void centerWidget(double _dScreenSizeRatio, QWidget *_screen_widget = NULL)
	{
		TxQtEnvironment::assertMainThread();
		return _TxPrivateNs_::CQtlib::centerWidget(this, _dScreenSizeRatio, _screen_widget);
	}
};

class TxQtlib : public _TxPrivateNs_::CQtlib
{
public:
	static void initEnv()
	{
		assertMainThread();
		_TxPrivateNs_::_MyQtWindowGlobal::getInstance();
		__super::initEnv();
	}
};


